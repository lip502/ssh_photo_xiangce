package com.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.Servlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.dao.TZhaopianDAO;
import com.model.TUser;
import com.model.TZhaopian;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class zhaopianAction
{
	private Integer id;
	private int xiangceId;
	private String title;
	private String fujian;

	private String jieshao;
	private String shijian;

	
	private TZhaopianDAO zhaopianDAO;
	
	
	public String zhaopianAdd()
	{
		TZhaopian zhaopian=new TZhaopian();
		
		zhaopian.setXiangceId(xiangceId);
		zhaopian.setTitle(title);
		zhaopian.setFujian(fujian);
		zhaopian.setJieshao(jieshao);
		
		zhaopian.setShijian(new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date()));
		
		zhaopianDAO.save(zhaopian);
		
		HttpServletRequest request=ServletActionContext.getRequest();
		request.setAttribute("msg", "�ϴ�ͼƬ�ɹ�");
		return "msg";
	}

	
	public String zhaopianMine()
	{
		String sql="from TZhaopian where xiangceId="+xiangceId;
		List zhaopianList=zhaopianDAO.getHibernateTemplate().find(sql);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("zhaopianList", zhaopianList);
		return ActionSupport.SUCCESS;
	}

	public String zhaopianDel()
	{
		TZhaopian zhaopian=zhaopianDAO.findById(id);
		
		zhaopianDAO.delete(zhaopian);
		
		HttpServletRequest request=ServletActionContext.getRequest();
		request.setAttribute("msg", "ͼƬɾ���ɹ�");
		return "msg";
	}
	
	public String getFujian()
	{
		return fujian;
	}


	public void setFujian(String fujian)
	{
		this.fujian = fujian;
	}


	public Integer getId()
	{
		return id;
	}


	public void setId(Integer id)
	{
		this.id = id;
	}


	public String getJieshao()
	{
		return jieshao;
	}



	public void setJieshao(String jieshao)
	{
		this.jieshao = jieshao;
	}


	public String getShijian()
	{
		return shijian;
	}


	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}


	public String getTitle()
	{
		return title;
	}


	public void setTitle(String title)
	{
		this.title = title;
	}


	public int getXiangceId()
	{
		return xiangceId;
	}


	public void setXiangceId(int xiangceId)
	{
		this.xiangceId = xiangceId;
	}


	public TZhaopianDAO getZhaopianDAO()
	{
		return zhaopianDAO;
	}


	public void setZhaopianDAO(TZhaopianDAO zhaopianDAO)
	{
		this.zhaopianDAO = zhaopianDAO;
	}
	
}
