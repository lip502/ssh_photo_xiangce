package com.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.Servlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.dao.TXiangceDAO;
import com.model.TUser;
import com.model.TXiangce;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class xiangceAction
{
	private Integer id;
	private String name;
	private String shijian;
	private Integer userId;
	
	private TXiangceDAO xiangceDAO;
	
	public String xiangceAdd()
	{
		HttpServletRequest request=ServletActionContext.getRequest();
		HttpSession session=request.getSession();
		TUser user=(TUser)session.getAttribute("user");
		
		TXiangce xiangce=new TXiangce();
		
		xiangce.setName(name);
		xiangce.setShijian(new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date()));
		xiangce.setUserId(user.getUserId());
		
		xiangceDAO.save(xiangce);
		request.setAttribute("msg", "����½��ɹ�");
		return "msg";
	}
	
	public String xiangceMine()
	{
		HttpServletRequest request=ServletActionContext.getRequest();
		HttpSession session=request.getSession();
		TUser user=(TUser)session.getAttribute("user");
		
		String sql="from TXiangce where userId="+user.getUserId();
		
		List xiangceList=xiangceDAO.getHibernateTemplate().find(sql);
		
		request.setAttribute("xiangceList", xiangceList);
		return ActionSupport.SUCCESS;
	}
	
	public String xiangceDel()
	{
		TXiangce xiangce=xiangceDAO.findById(id);
		
		xiangceDAO.delete(xiangce);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("msg", "���ɾ���ɹ�");
		return "msg";
	}
	
	public String xiangceSelect()
	{
		HttpServletRequest request=ServletActionContext.getRequest();
		HttpSession session=request.getSession();
		TUser user=(TUser)session.getAttribute("user");
		
		String sql="from TXiangce where userId="+user.getUserId();
		
		List xiangceList=xiangceDAO.getHibernateTemplate().find(sql);
		
		request.setAttribute("xiangceList", xiangceList);
		return ActionSupport.SUCCESS;
	}

	public Integer getId()
	{
		return id;
	}



	public void setId(Integer id)
	{
		this.id = id;
	}


	public String getShijian()
	{
		return shijian;
	}



	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}



	public String getName()
	{
		return name;
	}




	public void setName(String name)
	{
		this.name = name;
	}



	public TXiangceDAO getXiangceDAO()
	{
		return xiangceDAO;
	}



	public void setXiangceDAO(TXiangceDAO xiangceDAO)
	{
		this.xiangceDAO = xiangceDAO;
	}



	public Integer getUserId() {
		return userId;
	}



	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	
}
